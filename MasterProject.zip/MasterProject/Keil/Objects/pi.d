.\objects\pi.o: ..\User\src\PI.c
.\objects\pi.o: ..\User\inc\PI.h
.\objects\pi.o: C:\Users\Administrator\AppData\Local\Keil_v5\ARM\ARMCompiler_506\Bin\..\include\stdint.h
.\objects\pi.o: ..\User\inc\Q15Math.h
