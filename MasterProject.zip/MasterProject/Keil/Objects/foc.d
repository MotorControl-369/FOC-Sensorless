.\objects\foc.o: ..\User\src\FOC.c
.\objects\foc.o: ..\User\inc\FOC.h
.\objects\foc.o: ..\User\inc\PI.h
.\objects\foc.o: ..\User\inc\SMO.h
.\objects\foc.o: C:\Users\Administrator\AppData\Local\Keil_v5\ARM\ARMCompiler_506\Bin\..\include\stdint.h
.\objects\foc.o: ..\User\inc\SVPWM.h
.\objects\foc.o: ..\User\inc\Motor.h
.\objects\foc.o: ..\User\inc\SinLut.h
