.\objects\devicepro.o: ..\Device\DevicePro.c
