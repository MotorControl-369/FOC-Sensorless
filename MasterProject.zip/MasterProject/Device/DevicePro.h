


//typedef struct
//{					
//	__IO uint32_t PMS;
//	__IO uint32_t DOM;	
//	union{	
//	__IO uint32_t DO;
//	gpio_io_do_t DO_f;	
//		};
//	union{
//	__I  uint32_t DI;
//	gpio_io_di_t DI_f;
//		};
//	__IO uint32_t IMSC;	
//	__I  uint32_t RIS;
//	__I  uint32_t MIS;
//	__IO uint32_t ICLR;	
//	__IO uint32_t ITYPE;	
//	__IO uint32_t IVAL;
//	__IO uint32_t IANY;	
//	__IO uint32_t DIDB;
//	__O  uint32_t DOSET;			
//	__O  uint32_t DOCLR;
//	__IO uint32_t DR;
//	__IO uint32_t SR;
//} GPIO_T;