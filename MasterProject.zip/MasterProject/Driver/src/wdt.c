/*******************************************************************************
* Copyright (C) 2019 China Micro Semiconductor Limited Company. All Rights Reserved.
*
* This software is owned and published by:
* CMS LLC, No 2609-10, Taurus Plaza, TaoyuanRoad, NanshanDistrict, Shenzhen, China.
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with CMS
* components. This software is licensed by CMS to be adapted only
* for use in systems utilizing CMS components. CMS shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. CMS is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/****************************************************************************/
/** \file wdt.c
**
**	History:
**	
*****************************************************************************/
/****************************************************************************/
/*	include files
*****************************************************************************/
#include "wdt.h"
/****************************************************************************/
/*	Local pre-processor symbols/macros('#define')
*****************************************************************************/

/****************************************************************************/
/*	Global variable definitions(declared in header file with 'extern')
*****************************************************************************/

/****************************************************************************/
/*	Local type definitions('typedef')
*****************************************************************************/

/****************************************************************************/
/*	Local variable  definitions('static')
*****************************************************************************/


/****************************************************************************/
/*	Local function prototypes('static')
*****************************************************************************/

/****************************************************************************/
/*	Function implementation - global ('extern') and local('static')
*****************************************************************************/
/*****************************************************************************
 ** \brief	 WDT_Delay
 **			 ����WDT��ʱ1��WDT clock
 ** \return  none
*****************************************************************************/
void WDT_Delay(void)
{
	uint8_t SysClk,ClkFre;
	uint32_t i,WdtDlay=0;
	ClkFre = WDT->CON & WDT_WDTCON_WDTPRE_Msk ;
	ClkFre = ClkFre >> WDT_WDTCON_WDTPRE_Pos;
	
	SysClk = SYSCON->CLKCON & SYS_CLKCON_IRCSEL_Msk;
	if(SysClk == 0)  	//64MHz
		WdtDlay = 268;  //30us
	else						 	//48MHz
		WdtDlay = 202;  //30us
	
	if(ClkFre == 1)
		WdtDlay = WdtDlay * 16;    //16��Ƶ
	else if(ClkFre == 2)
		WdtDlay = WdtDlay * 256;   //256��Ƶ
	
	for(i=0; i<WdtDlay; i++);
	 
}
/*****************************************************************************
 ** \brief	 WDT_EnableRestSystem
 **			 ����WDT�����λϵͳ
 ** \return  none
 ** \note	(1)ʹ��WDT ��λ��������WDT �жϺ�û�����жϱ�־λ���´η���WDT�ж�ʱ����WDT��λ.
 **			(2)��ʹ�ܸ�λʱ������ʹ��WDT�ж�.
*****************************************************************************/
void WDT_EnableRestSystem(void)
{
	uint8_t WDT_Tim=5;
	WDT->LOCK = WDT_LOCK_WRITE_KEY;	
	if(WDT->CON & WDT_WDTCON_WDTIEN_Msk)
		WDT->CON &= ~(WDT_WDTCON_WDTEN_Msk);
	else
	{
		while(WDT_Tim)
		{
			WDT->CON |= (WDT_CON_WRITE_KEY);
			WDT_Delay();		
			WDT->CON &= ~(WDT_WDTCON_WDTEN_Msk);
			WDT_Delay();
			if(((WDT_Load -5) <= WDT->VAL)&&(WDT->VAL <= WDT_Load))
				break;			
			WDT_Tim --;
		}
	}
		
	WDT->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 WDT_DisableRestSystem
 **			 �ر�WDT�����λϵͳ
 ** \return  none
 ** \note	
*****************************************************************************/
void WDT_DisableRestSystem(void)
{
	uint32_t temp;
	
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	temp = WDT->CON;
	temp &= ~(WDT_WDTCON_WDTEN_Msk);
	temp |= (WDT_CON_WRITE_KEY);
	WDT->CON = temp;
	WDT->LOCK = 0x0;		
}

/*****************************************************************************
 ** \brief	 WDT_ConfigClk
 **			 ����WDTʱ��
 ** \param [in] ClkDiv: (1)WDT_CLK_DIV_1   
 **						(2)WDT_CLK_DIV_16  
 **						(3)WDT_CLK_DIV_256 
 ** \return  none
 ** \note	
*****************************************************************************/
void WDT_ConfigClk(uint32_t ClkDiv)
{
	uint32_t temp;
	
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	temp = WDT->CON;
	temp &= ~(WDT_WDTCON_WDTPRE_Msk);
	temp |= (ClkDiv);
	WDT->CON = temp;
	WDT->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 WDT_ConfigPeriod
 **			 ����WDT�������
 ** \param [in] Period: 32BitValue
 ** \return  none
 ** \note	 
*****************************************************************************/
void WDT_ConfigPeriod(uint32_t Period)
{
	uint8_t WDT_Tim=5;
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	if((WDT->CON & WDT_WDTCON_WDTIEN_Msk)
		||((WDT->CON & WDT_WDTCON_WDTEN_Msk) != WDT_CON_WRITE_KEY))
	{
		while(WDT_Tim)
		{
			WDT->LOAD = Period;
			WDT_Delay();
			if(((Period -5) <= WDT->VAL)&&(WDT->VAL <= Period))
					break;
			WDT_Tim --;
		}
	}
	else
		WDT->LOAD = Period;
	WDT->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 WDT_EnableOverflowInt
 **			 ����WDT����ж�
 ** \return  none
 ** \note	 
*****************************************************************************/
void WDT_EnableOverflowInt(void)
{
	uint8_t WDT_Tim=5;
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	if((WDT->CON & WDT_CON_WRITE_KEY) == WDT_CON_WRITE_KEY)
	{
		while(WDT_Tim)
		{
			WDT->CON &= ~(WDT_WDTCON_WDTIEN_Msk);
			WDT_Delay();
			WDT->CON |= WDT_WDTCON_WDTIEN_Msk;
			WDT_Delay();
			if(((WDT_Load -5) <= WDT->VAL)&&(WDT->VAL <= WDT_Load))
					break;			
			WDT_Tim --;
		}
	}
	else
		WDT->CON |= WDT_WDTCON_WDTIEN_Msk;
	WDT->LOCK = 0x0;			
}


/*****************************************************************************
 ** \brief	 WDT_DisableOverflowInt
 **			 �ر�WDT����ж�
 ** \return  none
 ** \note	 
*****************************************************************************/
void WDT_DisableOverflowInt(void)
{
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	WDT->CON &= ~(WDT_WDTCON_WDTIEN_Msk);
	WDT->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 WDT_GetOverflowIntFlag
 **			 ��ȡWDTʹ�ܲ������жϱ�־
 ** \return  1:ʹ���жϲ������ж� 0�����ж�
 ** \note	 
*****************************************************************************/
uint32_t WDT_GetOverflowIntFlag(void)
{
	return((WDT->MIS & WDT_WDTMIS_WDTMIS_Msk)? 1:0);
}
/*****************************************************************************
 ** \brief	 WDT_ClearOverflowIntFlag
 **			 ���WDT�жϱ�־�����¼��س�ֵ
 ** \return none
 ** \note	 
*****************************************************************************/
void WDT_ClearOverflowIntFlag(void)
{
	uint8_t WDT_Tim=5;
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	while(WDT_Tim)
	{
		WDT->ICLR = WDT_ICLR_WRITE_KEY;
		WDT_Delay();
		if(((WDT_Load -5) <= WDT->VAL)&&(WDT->VAL <= WDT_Load))
		{
			if(WDT->RIS == 0)
				break;
		}	
		WDT_Tim --;
	}
	WDT->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 WDT_GetTimingData
 **			 ��ȡWDT����ֵ
 ** \return 32bit value
 ** \note	 
*****************************************************************************/
uint32_t WDT_GetTimingData(void)
{
	return(WDT->VAL);
}

/*****************************************************************************
 ** \brief	 WDT_ClearWDT
 **			 ι��
 ** \return none
 ** \note	 
*****************************************************************************/
void WDT_ClearWDT(void)
{
	uint8_t WDT_Tim=5;
	WDT->LOCK = WDT_LOCK_WRITE_KEY;
	while(WDT_Tim)
	{
		WDT->ICLR = WDT_ICLR_WRITE_KEY;
		WDT_Delay();
		if(((WDT_Load -5) <= WDT->VAL)&&(WDT->VAL <= WDT_Load))
		{
			if(WDT->RIS == 0)
				break;
		}	
		WDT_Tim --;
	}
	WDT->LOCK = 0x0;
}

