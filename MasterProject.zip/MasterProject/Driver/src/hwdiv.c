#include "hwdiv.h"

/*****************************************************************************
 ** \brief	HWDIV_Div
 **			ʵ�� "/" (ȡ��)
 ** \param [in] x:������
 **				y:����
 ** \return  none
 ** \note	 
*****************************************************************************/
int32_t HWDIV_Div(int32_t x, int32_t y)
{
    uint32_t* Point;
    Point = (uint32_t *)& HWDIV->DIVD;
    *Point++ = x;
    *Point++ = y;
	while(!HWDIV_IS_IDLE())
	{
		;
	}
	
    return *Point;   
}
	  
/*****************************************************************************
 ** \brief	HWDIV_Mod
 **			ʵ�� "%" (ȡ��)
 ** \param [in] x:������
 **				y:����
 ** \return  none
 ** \note	 
*****************************************************************************/
int32_t HWDIV_Mod(int32_t x, int32_t y)
{
    uint32_t *Point;
    Point = (uint32_t *)& HWDIV->DIVD;
    *Point++ = x;
    *Point++ = y;
	while(!HWDIV_IS_IDLE())
	{
		;
	}
    return (Point[1]);   
}

/*****************************************************************************
 ** \brief	HWDIV_EnableSingedMode
 **			ʹ���з��ų���������
 ** \return  none
 ** \note	
*****************************************************************************/
void HWDIV_EnableSingedMode(void)
{
	HWDIV->CON |= HDIV_CON_SIGN_Msk;
}
/*****************************************************************************
 ** \brief	HWDIV_EnableUnsingedMode
 **			ʹ���޷��ų���������
 ** \return  none
 ** \note	
*****************************************************************************/
void HWDIV_EnableUnsingedMode(void)
{
	HWDIV->CON &= ~(HDIV_CON_SIGN_Msk);
}



