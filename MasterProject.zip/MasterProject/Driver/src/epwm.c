
#include "epwm.h"
/*****************************************************************************
 ** \brief	 EPWM_ConfigRunMode
 **			 ����EPWM������ģʽ
 ** \param [in] EpwmRunMode: (1)EPWM_COUNT_UP_DOWN
							   (2)EPWM_COUNT_DOWN
							   (3)EPWM_OCU_ASYMMETRIC
							   (4)EPWM_OCU_SYMMETRIC
							   (5)EPWM_WFG_INDEPENDENT
							   (6)EPWM_WFG_COMPLEMENTARY
							   (7)EPWM_WFG_SYNCHRONIZED
							   (8)EPWM_OC_MODE_GROUP
							   (9)EPWM_OC_INDEPENDENT
 ** \return  none
 ** \note    
*****************************************************************************/
void EPWM_ConfigRunMode(uint32_t EpwmRunMode)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->CON &= ~(EPWM_CON_MODE_Msk | EPWM_CON_GROUNPEN_Msk | EPWM_CON_ASYMEN_Msk);
	EPWM->CON |= EpwmRunMode;
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_ConfigChannelClk	
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **				ClkDiv: (1)EPWM_CLK_DIV_1 
 **						(2)EPWM_CLK_DIV_2
 **						(3)EPWM_CLK_DIV_4
 **						(4)EPWM_CLK_DIV_8
 **						(5)EPWM_CLK_DIV_16
 **						(6)EPWM_CLK_DIV_32
 ** \return  none	
 ** \note 
 **	(1)����ΪCLKPSC01��ͬ����PWM0��PWM1ͨ�� �����Դ˺���ͳһ����CLKPSC01=0x01
 **     ����Ҫ�����ķ�Ƶ��������ԼĴ�����ֵ.  
*****************************************************************************/
void EPWM_ConfigChannelClk(uint32_t EPWMn,uint32_t ClkDiv)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CLKPSC = (0x01<<EPWM_CLKPSC_CLKPSC45_Pos |
					0x01<<EPWM_CLKPSC_CLKPSC23_Pos |
					0x01<<EPWM_CLKPSC_CLKPSC01_Pos);
	EPWM->CLKDIV &= ~(0xfUL <<(EPWMn*4));
	EPWM->CLKDIV |= (ClkDiv <<(EPWMn*4));		
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_ConfigChannelPeriod	
 **			 ����EPWMͨ��������
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **				Period: 16λ����ֵ
 ** \return none
 ** \note    
*****************************************************************************/
void EPWM_ConfigChannelPeriod(uint32_t EPWMn, uint32_t Period)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->PERIOD[EPWMn] = 0xffff & Period;
	EPWM->CON3 |= (0x1UL <<(EPWMn + EPWM_CON3_LOADEN0_Pos));		/*ʹ�ܼ�������&&ռ�ձ�*/
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_ConfigChannelSymDuty	
 **			 ���öԳ�ģʽ�µ�EPWMͨ����ռ�ձ�
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **			    Duty  : 16λ�Ƚ�ֵ
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_ConfigChannelSymDuty(uint32_t EPWMn,uint32_t Duty)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->CMPDAT[EPWMn] &= 0xffff0000;
	EPWM->CMPDAT[EPWMn] |= 0xffff & Duty;	
	EPWM->CON3 |= (0x1UL <<(EPWMn +EPWM_CON3_LOADEN0_Pos));		/*ʹ�ܼ�������&&ռ�ձ�*/
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_ConfigChannelAsymDuty	
 **			 ���÷ǶԳ�ģʽ�µ� EPWMͨ����ռ�ձ�
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **			    UpCmp 	  : 16λ���ϱȽ�ֵ
 **			    DownCmp   : 16λ���±Ƚ�ֵ
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_ConfigChannelAsymDuty(uint32_t EPWMn,uint32_t UpCmp, uint32_t DownCmp)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->CMPDAT[EPWMn] = (0xffff & UpCmp) | ((0xffff & DownCmp)<<16);	
	EPWM->CON3 |= (0x1UL <<(EPWMn +EPWM_CON3_LOADEN0_Pos));		/*ʹ�ܼ�������&&ռ�ձ�*/
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_EnableOneShotMode	
 **			 ʹ�ܵ���ģʽ
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_EnableOneShotMode(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON &= ~(EPWMnMask); 
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_EnableAutoLoadMode	
 **			 ʹ����������ģʽ
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_EnableAutoLoadMode(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON |= EPWMnMask; 
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_ConfigLoadAndIntMode
 **			 ���ü��ط�ʽ�Լ��жϷ�ʽ
 ** \param [in]  EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **				 Mode: (1)EPWM_EACH_PERIOD_ZERO
 **					   (2)EPWM_EACH_ZERO
 **					   (3)EPWM_FIRST_ZERO_NEXT_PERIOD
 **					   (4)EPWM_EVERY_TWO_ZERO
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_ConfigLoadAndIntMode(uint32_t EPWMn, uint32_t Mode)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON3 &= ~(0x3UL<< ((EPWMn*2) + EPWM_CON3_LOADTYP0_Pos));
	EPWM->CON3 |= Mode << ((EPWMn*2) + EPWM_CON3_LOADTYP0_Pos);	
	EPWM->LOCK = 0x0;			
}

/*****************************************************************************
 ** \brief	 EPWM_EnableReverseOutput	
 **			 �����������
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_EnableReverseOutput(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON |= (EPWMnMask<< EPWM_CON_PINV0_Pos); 
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_DisableReverseOutput	
 **			 �رշ������
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_DisableReverseOutput(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON &= ~(EPWMnMask<< EPWM_CON_PINV0_Pos); 
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_EnableDeadZone	
 **			 ��������
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 **				DeadZone : 0x00 ~ 0x3FF;
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_EnableDeadZone(uint32_t EPWMnMask, uint32_t DeadZone)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	if(( EPWMnMask & EPWM_CH_0_MSK) || (EPWMnMask & EPWM_CH_1_MSK))
	{
		EPWM->CON |= EPWM_CON_ENDT01_Msk;
		EPWM->DTCTL &= ~(EPWM_DTCTL_DTI01_Msk);
		EPWM->DTCTL |= 0x3ff & DeadZone;
	}
	if(( EPWMnMask & EPWM_CH_2_MSK) || (EPWMnMask & EPWM_CH_3_MSK))
	{
		EPWM->CON |= EPWM_CON_ENDT23_Msk;
		EPWM->DTCTL &= ~(EPWM_DTCTL_DTI23_Msk);
		EPWM->DTCTL |=  ((0x3ff & DeadZone)<<EPWM_DTCTL_DTI23_Pos);
	}	
	if(( EPWMnMask & EPWM_CH_4_MSK) || (EPWMnMask & EPWM_CH_5_MSK))
	{
		EPWM->CON |= EPWM_CON_ENDT45_Msk;
		EPWM->DTCTL &= ~(EPWM_DTCTL_DTI45_Msk);
		EPWM->DTCTL |= (0x3ff & DeadZone) << EPWM_DTCTL_DTI45_Pos;
	}	
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_DisableDeadZone	
 **			 �ر�����
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_DisableDeadZone(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	if(( EPWMnMask & EPWM_CH_0_MSK) || (EPWMnMask & EPWM_CH_1_MSK))
	{
		EPWM->CON &= ~(EPWM_CON_ENDT01_Msk);
	}
	if(( EPWMnMask & EPWM_CH_2_MSK) || (EPWMnMask & EPWM_CH_3_MSK))
	{
		EPWM->CON &= ~(EPWM_CON_ENDT23_Msk);
	}	
	if(( EPWMnMask & EPWM_CH_4_MSK) || (EPWMnMask & EPWM_CH_5_MSK))
	{
		EPWM->CON &= ~(EPWM_CON_ENDT45_Msk);
	}	
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_EnableChannelRemap	
 **			 ����ͨ����ӳ��
 ** \param [in]  EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 
 **				 IPGn  : IPG0 ��IPG1 ��IPG2 ��IPG3 ��IPG4 ��IPG5 
 ** \return none
 ** \note   IPGxָ�ڲ�ͨ����EPWMxָ�ⲿ���ͨ��
*****************************************************************************/
void EPWM_EnableChannelRemap(uint32_t EPWMn, uint32_t IPGn)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->POREMAP &= ~((EPWM_POREMAP_PWMRMEN_Msk) | (0xf<<(EPWMn * 4)));
	EPWM->POREMAP |= (EPWM_REMAP_ENABLE<< EPWM_POREMAP_PWMRMEN_Pos) |(IPGn<< (EPWMn * 4));
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_DisableChannelRemap	
 **			 �ر�ͨ����ӳ��
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_DisableChannelRemap(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->POREMAP &= ~(EPWM_POREMAP_PWMRMEN_Msk);
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_EnableOutput
 **			 ����EPWMͨ�����
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note  
*****************************************************************************/
void EPWM_EnableOutput(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->POEN |= EPWMnMask;
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_DisableOutput
 **			 �ر�EPWMͨ�����
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_DisableOutput(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->POEN &= ~(EPWMnMask);
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_Start	
 **			 ����EPWM
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_Start(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON2 |= EPWMnMask;	
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_Stop	
 **			 �ر�EPWM
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_Stop(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CON2 &= ~(EPWMnMask);			
	EPWM->CON3 |= EPWMnMask;			/*������0*/
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_ForceStop	
 **			 ǿ�ƹر�EPWM
 ** \return none
 ** \note   ʹ���������EPWM
*****************************************************************************/
void EPWM_ForceStop(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_WriteMaskBuffer
 **			 д����Ԥ���ػ���
 ** \param [in] MaskBuffer:  EPWM_MASK_BUF0 ��EPWM_MASK_BUF1��EPWM_MASK_BUF2��EPWM_MASK_BUF3
 **							 EPWM_MASK_BUF4��EPWM_MASK_BUF5��EPWM_MASK_BUF6��EPWM_MASK_BUF7
 **				BufferValue: 16bit
 ** \return none
 ** \note   HALLEN=0 ʱ��Ĭ�ϼ�������Ԥ�軺��0�е����ݡ�
*****************************************************************************/
void EPWM_WriteMaskBuffer(uint32_t MaskBuffer, uint32_t BufferValue)
{
	uint32_t Temp;
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	Temp = EPWM->MASKNXT;
	Temp &= ~(EPWM_MASKNXT_PMASKSEL_Msk | 0xffff);
	Temp |= (MaskBuffer<<EPWM_MASKNXT_PMASKSEL_Pos) | BufferValue;
	EPWM->MASKNXT = Temp;
	EPWM->LOCK = 0x0;		
}


/*****************************************************************************
 ** \brief	 EPWM_ConfigCompareTriger
 **			 ���ô����Ƚ���
 ** \param [in]CmpTgn: EPWM_CMPTG_0��EPWM_CMPTG_1
 **			   CmpTgMode: (1)EPWM_CMPTG_FALLING
 **						  (2)EPWM_CMPTG_RISING
 **			   CmpTgCounter: (1)EPWM_CMPTG_EPWM0
 **							 (2)EPWM_CMPTG_EPWM1
 **							 (3)EPWM_CMPTG_EPWM2
 **							 (4)EPWM_CMPTG_EPWM3
 **							 (5)EPWM_CMPTG_EPWM4
 **							 (6)EPWM_CMPTG_EPWM5
 **			   CmpTgData: 0x00~ 0xffff;
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_ConfigCompareTriger(uint32_t CmpTgn, uint32_t CmpTgMode,uint32_t CmpTgCounter, uint32_t CmpTgData)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->CMPTGD[CmpTgn] = (CmpTgMode<<EPWM_CMPTGD_CMPTGDS_Pos)    |
						   (CmpTgCounter<<EPWM_CMPTGD_CMPPCHS_Pos) |
						   (0xffff & CmpTgData);	
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_EnableHall
 **			 ����Hallģʽ���
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_EnableHall(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->MASKNXT |= EPWM_MASKNXT_HALLEN_Msk;
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_DisableHall
 **			 �ر�Hallģʽ���
 ** \return none
 ** \note   
*****************************************************************************/
void EPWM_DisableHall(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->MASKNXT &= ~(EPWM_MASKNXT_HALLEN_Msk);
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_GetHallState
 **			 ��ȡHall�ӿ�״̬
 ** \return Hall State
 ** \note   
*****************************************************************************/
uint32_t  EPWM_GetHallState(void)
{
	return((EPWM->MASKNXT & EPWM_MASKNXT_HALLST_Msk)>>EPWM_MASKNXT_HALLST_Pos);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearHallErrorState
 **			 ���Hall�ӿڴ���״̬
 ** \return none
 ** \note  ������ֵĴ����״̬��������ʱ��HALLST=111��HALL ��⹦��ֹͣ��
 **			�ٴμ�⿪�� HALL ״̬ʱ����Ҫ��������״̬�� 
*****************************************************************************/
void  EPWM_ClearHallErrorState(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->MASKNXT |= EPWM_MASKNXT_HALLCLR_Msk;
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_AllBrakeEnable
 **			 ����ɲ����ʹ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_AllBrakeEnable(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL |= EPWM_BRKCTL_BRKEN_Msk;	
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_AllBrakeDisable
 **			�ر�ɲ����ʹ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_AllBrakeDisable(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL &= ~(EPWM_BRKCTL_BRKEN_Msk);	
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_EnableFaultBrake
 **			 ����ɲ��
 ** \param [in] BrakeSource:(1)EPWM_BRK_SOFT:����ɲ��
 **							(2)EPWM_BRK_EXTLE 		�ⲿӲ����ƽɲ��
 **							(3)EPWM_BRK_EXTEE 		�ⲿӲ������ɲ��
 **							(4)EPWM_BRK_ADCBCMP0 	ADCB�Ƚ���0ɲ��
 **							(5)EPWM_BRK_ACMP0EE  	ģ��Ƚ���0�¼�ɲ��
 **							(6)EPWM_BRK_ACMP1EE  	ģ��Ƚ���1�¼�ɲ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableFaultBrake(uint32_t BrakeSource)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL |= BrakeSource;
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_DisableFaultBrake
 **			 �ر�ɲ��
 ** \param [in] BrakeSource:(1)EPWM_BRK_SOFT:����ɲ��
 **							(2)EPWM_BRK_EXTLE 		�ⲿӲ����ƽɲ��
 **							(3)EPWM_BRK_EXTEE 		�ⲿӲ������ɲ��
 **							(4)EPWM_BRK_ADCBCMP0 	ADCB�Ƚ���0ɲ��
 **							(5)EPWM_BRK_ACMP0EE  	ģ��Ƚ���0�¼�ɲ��
 **							(6)EPWM_BRK_ACMP1EE  	ģ��Ƚ���1�¼�ɲ��		
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableFaultBrake(uint32_t BrakeSource)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL &= ~(BrakeSource);
	EPWM->LOCK = 0x0;
}

/*****************************************************************************
 ** \brief	 EPWM_ConfigFaultBrakeLevel
 **			 ����EPWMnɲ����ƽ
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 **				BrakeLevel:  0���͵�ƽ  1���ߵ�ƽ			
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ConfigFaultBrakeLevel(uint32_t EPWMnMask, uint32_t BrakeLevel)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	if(BrakeLevel)
	{
		EPWM->BRKCTL |= EPWMnMask;
	}
	else
	{
		EPWM->BRKCTL &= ~(EPWMnMask);		
	}
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_EnableEXTLEBrake
 **			 �����ⲿӲ����ƽɲ��ģʽ
 ** \param [in] BrakeMode��	(1) EPWM_EXTBK_LEVEL_HIGH		�ߵ�ƽɲ��
 **					   		(2)	EPWM_EXTBK_LEVEL_LOW		�͵�ƽɲ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableEXTLEBrake(uint32_t BrakeMode)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL &= ~(EPWM_BRKCTL_EXTBRKLS_Msk);
	EPWM->BRKCTL |= BrakeMode;
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_EnableEXTEEBrake
 **			 �����ⲿӲ������ɲ��ģʽ
 ** \param [in] BrakeMode��	(1)	EPWM_EXTBK_EDGE_FALLING 	�½���ɲ��
 **					   		(2) EPWM_EXTBK_EDGE_RISING		������ɲ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableEXTEEBrake(uint32_t BrakeMode)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
	EPWM->BRKCTL &= ~(EPWM_BRKCTL_EXTBRKES_Msk);
	EPWM->BRKCTL |= BrakeMode;
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_EnableSoftwareBrake
 **			 ʹ������ɲ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableSoftwareBrake(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->BRKCTL |=	EPWM_BRKCTL_SWBRK_Msk;
	EPWM->LOCK = 0x0;		
}

/*****************************************************************************
 ** \brief	 EPWM_DisableSoftwareBrake
 **			 �ر�����ɲ��
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableSoftwareBrake(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;		
	EPWM->BRKCTL &= ~(EPWM_BRKCTL_SWBRK_Msk);
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_EnableBrakeInt
 **			 ����ɲ���ж�
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableBrakeInt(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= EPWM_IMSC_ENBRKIF_Msk;
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_DisableBrakeInt
 **			 �ر�ɲ���ж�
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableBrakeInt(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWM_IMSC_ENBRKIF_Msk);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_GetBrakeIntFlag
 **			��ȡɲ���ж�ʹ�ܲ������жϱ�־λ
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetBrakeIntFlag(void)
{
	return ((EPWM->MIS&EPWM_MIS_BRKIF_Msk)? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearBrakeIntFlag
 **			���ɲ���жϱ�־λ
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearBrakeIntFlag(void)
{
	EPWM->ICLR |= EPWM_ICLR_BRKIF_Msk;
}


/*****************************************************************************
 ** \brief	 EPWM_EnableHallErrorInt
 **			 ����Hall״̬�����ж�
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableHallErrorInt(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= EPWM_IMSC_ENHALLIF_Msk;
	EPWM->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 EPWM_DisableHallErrorInt
 **			 �ر�Hall״̬�����ж�
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableHallErrorInt(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWM_IMSC_ENHALLIF_Msk);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_GetHallErrorIntFlag
 **			��ȡHall״̬�����ж�ʹ�ܲ������жϱ�־λ
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetHallErrorIntFlag(void)
{
	return ((EPWM->MIS&EPWM_MIS_HALLIF_Msk)? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearHallErrorIntFlag
 **			���Hall״̬�����жϱ�־λ
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearHallErrorIntFlag(void)
{
	EPWM->ICLR |= (EPWM_ICLR_HALLIF_Msk);
}

/*****************************************************************************
 ** \brief	 EPWM_EnableUpCmpInt
 **			 �������ϱȽ��ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableUpCmpInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= (EPWMnMask<<EPWM_IMSC_ENUIFn_Pos);
	EPWM->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 EPWM_DisableUpCmpInt
 **			 �ر����ϱȽ��ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableUpCmpInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWMnMask<<EPWM_IMSC_ENUIFn_Pos);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_GetUpCmpIntFlag
 **			��ȡ���ϱȽ��ж�ʹ�ܲ������жϱ�־λ
 ** \param [in]EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetUpCmpIntFlag(uint32_t EPWMn)
{
	return ((EPWM->MIS&(0x01UL<<(EPWMn+EPWM_MIS_UIFn_Pos)))? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearUpCmpIntFlag
 **			������ϱȽ��жϱ�־λ
 ** \param [in]EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearUpCmpIntFlag(uint32_t EPWMn)
{
	EPWM->ICLR |= (0x1UL<<(EPWMn+EPWM_ICLR_UIFn_Pos));
}

/*****************************************************************************
 ** \brief	 EPWM_EnableDownCmpInt
 **			 �������±Ƚ��ж�
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableDownCmpInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= (EPWMnMask<<EPWM_IMSC_ENDIFn_Pos);
	EPWM->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 EPWM_DisableDownCmpInt
 **			 �ر����±Ƚ��ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableDownCmpInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWMnMask<<EPWM_IMSC_ENDIFn_Pos);
	EPWM->LOCK = 0x0;
}
/*****************************************************************************
 ** \brief	 EPWM_GetDownCmpIntFlag
 **			��ȡ���±Ƚ��ж�ʹ�ܲ������жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetDownCmpIntFlag(uint32_t EPWMn)
{
	return ((EPWM->MIS&(0x01UL<<(EPWMn+EPWM_MIS_DIFn_Pos)))? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearDownCmpIntFlag
 **			������±Ƚ��жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearDownCmpIntFlag(uint32_t EPWMn)
{
	EPWM->ICLR |= (0x1UL<<(EPWMn+EPWM_ICLR_DIFn_Pos));	
}


/*****************************************************************************
 ** \brief	 EPWM_EnablePeriodInt
 **			 ���������ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnablePeriodInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= (EPWMnMask<<EPWM_IMSC_ENPIFn_Pos);
	EPWM->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 EPWM_DisablePeriodInt
 **			 �ر������ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisablePeriodInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWMnMask<<EPWM_IMSC_ENPIFn_Pos);
	EPWM->LOCK = 0x0;		
}
/*****************************************************************************
 ** \brief	 EPWM_GetPeriodIntFlag
 **			��ȡ�����ж�ʹ�ܲ������жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetPeriodIntFlag(uint32_t EPWMn)
{
	return ((EPWM->MIS&(0x01UL<<(EPWMn+EPWM_MIS_PIFn_Pos)))? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearPeriodIntFlag
 **			��������жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearPeriodIntFlag(uint32_t EPWMn)
{
	EPWM->ICLR |= (0x1UL<<(EPWMn+EPWM_ICLR_PIFn_Pos));
}

/*****************************************************************************
 ** \brief	 EPWM_EnableZeroInt
 **			 ��������ж�
 ** \param [in]  EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableZeroInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= (EPWMnMask<<EPWM_IMSC_ENZIFn_Pos);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_DisableZeroInt
 **			 �ر�����ж�
 ** \param [in] EPWMnMask : EPWM_CH_0_MSK ��EPWM_CH_1_MSK ��EPWM_CH_2_MSK ��
 **							 EPWM_CH_3_MSK ��EPWM_CH_4_MSK ��EPWM_CH_5_MSK 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableZeroInt(uint32_t EPWMnMask)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(EPWMnMask<<EPWM_IMSC_ENZIFn_Pos);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_GetZeroIntFlag
 **			��ȡ����ж�ʹ�ܲ������жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetZeroIntFlag(uint32_t EPWMn)
{
	return ((EPWM->MIS&(0x01UL<<(EPWMn+EPWM_MIS_ZIFn_Pos)))? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearZeroIntFlag
 **			�������жϱ�־λ
 ** \param [in] EPWMn : EPWM0 ��EPWM1 ��EPWM2 ��EPWM3 ��EPWM4 ��EPWM5 	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearZeroIntFlag(uint32_t EPWMn)
{
	EPWM->ICLR |= (0x1UL<<(EPWMn+EPWM_ICLR_ZIFn_Pos));
}


/*****************************************************************************
 ** \brief	 EPWM_EnableCountCmpInt
 **			 ���������Ƚ����ж�
 ** \param [in] EPWMCmp: EPWM_CMPTG_0 EPWM_CMPTG_1
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableCountCmpInt(uint32_t EPWMCmp)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC |= (0x1<<(EPWMCmp+EPWM_IMSC_ENDC0IF_Pos));
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_DisableCountCmp0Int
 **			 �رռ����Ƚ����ж�
 ** \param [in] EPWMCmp: EPWM_CMPTG_0 EPWM_CMPTG_1	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableCountCmpInt(uint32_t EPWMCmp)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IMSC &= ~(0x1<<(EPWMCmp+EPWM_IMSC_ENDC0IF_Pos));
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_GetCountCmpIntFlag
 **			��ȡ�����Ƚ����ж�ʹ�ܲ������жϱ�־λ
 ** \param [in] EPWMCmp: EPWM_CMPTG_0 EPWM_CMPTG_1	
 ** \return 1���ж�ʹ�ܲ��Ҳ����ж�  0�����ж�
 ** \note  
*****************************************************************************/
uint32_t  EPWM_GetCountCmpIntFlag(uint32_t EPWMCmp)
{
	return((EPWM->MIS & (0x1<<(EPWMCmp+EPWM_MIS_DC0IF_Pos)))? 1:0);
}
/*****************************************************************************
 ** \brief	 EPWM_ClearCountCmp0IntFlag
 **			��������Ƚ����жϱ�־λ
 ** \param [in] EPWMCmp: EPWM_CMPTG_0 EPWM_CMPTG_1	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ClearCountCmpIntFlag(uint32_t EPWMCmp)
{
	EPWM->ICLR |= (0x1<<(EPWMCmp+EPWM_ICLR_DC0IF_Pos));
}


/*****************************************************************************
 ** \brief	 EPWM_EnableZeroIntSum
 **			 ��������ж��ۼƹ���
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_EnableZeroIntSum(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IFA |= (EPWM_IFA_ZIFAEN_Msk);
	EPWM->LOCK = 0x0;	
}

/*****************************************************************************
 ** \brief	 EPWM_DisableZeroIntSum
 **			 �ر�����ж��ۼƹ���
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_DisableZeroIntSum(void)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IFA &= ~(EPWM_IFA_ZIFAEN_Msk);
	EPWM->LOCK = 0x0;	
}
/*****************************************************************************
 ** \brief	 EPWM_ConfigZeroIntSum
 **			 ��������ж��ۼƴ���
 ** \param [in] count : 0~0xf	
 ** \return none
 ** \note  
*****************************************************************************/
void  EPWM_ConfigZeroIntSum(uint32_t count)
{
	EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;	
	EPWM->IFA &= ~(EPWM_IFA_ZIFCMP_Msk);
	EPWM->IFA |= ((0xf & count) << EPWM_IFA_ZIFCMP_Pos);		
	EPWM->LOCK = 0x0;	
}



















/*****************************************************************************
Description : EPWM�������
Input       : ���״̬ ENABLE-���� DISABLE-�ع�
Return      : ��
Version     : 0.0.1 
History     : ����
Date        : 2022.2.12
Others      : �����������Ч��ƽ�޸Ĺع�����
*****************************************************************************/
void PWM_Out(uint8_t status)
{
    uint32_t tempMask;
    
    if(status == ENABLE)
    {
        EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY; 
        EPWM->MASK = 0x00000000;
        EPWM->LOCK = 0x0;
    }
    else if(status == DISABLE) 
    {
		tempMask = 0x00003F00;
        EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY; 
        EPWM->MASK = tempMask;
        EPWM->LOCK = 0x0;
    }
}













