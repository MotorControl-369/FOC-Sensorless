#include "CMS32M55xx.h"

uint8_t  g_KeyFlag     = 0u;            // 按键事件（KeyScan置位，Motor取用清零）
uint32_t g_PotSpeedCmd = 0u;            // 电位器指令0~4095（Motor映射成目标转速）

static volatile uint8_t s_Tick1msFlag = 0u; // 1ms节拍（SysTick置位，主循环清零）
static uint32_t s_PotFilt = 0u;         // 电位器滤波中间量



/*****************************************************************************
Name        : 低通滤波
Input       : raw  - 当前原始值
              last - 上次滤波结果
              n    - 滤波系数（越大越平滑）
Return      : 本次滤波结果
Description : 一阶递推：out = (raw + last x (n-1)) / n
*****************************************************************************/
static int32_t LP_Filter(int32_t raw, int32_t last, uint8_t n)
{
    return (raw + last * (n - 1)) / n;
}



/*****************************************************************************
Name        : 按键扫描
Input       : 无
Return      : 无
Description : 消抖扫描P44，检测到稳定按下沿后置位g_KeyFlag。
              1ms主循环调用。
*****************************************************************************/
static void KeyScan(void)
{
    static uint16_t downCnt = 0u;
    static uint8_t  upFlag  = 0u;

    if (((GPIO4->GPIO0DI) & (1u << 4)) == 0u)
    {
        if (downCnt < 65535u)
        {
            downCnt++;
        }
        if ((upFlag != 0u) && (downCnt > 5u))
        {
            upFlag   = 0u;
            g_KeyFlag = 1u;
        }
    }
    else
    {
        upFlag  = 1u;
        downCnt = 0u;
    }
}



/*****************************************************************************
Name        : 电位器扫描
Input       : 无
Return      : 无
Description : 读电位器ADC并低通滤波，更新g_PotSpeedCmd（取反：左小右大）。
              1ms主循环调用，非忙状态才读取，末尾启动下次转换。
*****************************************************************************/
static void Pot_Scan(void)
{
    if (ADC0_IS_BUSY() != 1u)
    {
        s_PotFilt = (uint32_t)LP_Filter((int32_t)ADC0_GetResult(POT_ADC_CH),(int32_t)s_PotFilt, 3u);
    }
    g_PotSpeedCmd = 4096u - s_PotFilt;
    ADC0_Go();
}



/*****************************************************************************
Name        : 系统时钟初始化
Input       : 无
Return      : 无
Description : 配置HSI为64MHz并选为AHB时钟源
*****************************************************************************/
void SysClock_Init(void)
{
    SYS_ConfigHSI(SYS_CLK_HSI_64M);
    SYS_EnableHSI();
    SYS_ConfigAHBClock(SYS_CLK_SEL_HSI, SYS_CLK_DIV_1);
    SYS_ConfigAPBClock(AHB_CLK_DIV_1);
    SystemCoreClockUpdate();
}



/*****************************************************************************
Name        : SysTick初始化
Input       : 无
Return      : 无
Description : 周期1ms，主循环时基（SysTick_Handler在main.c）
*****************************************************************************/
void SysTick_Init(void)
{
    SysTick_Config(MCU_CLK / 1000);
}



/*****************************************************************************
Name        : GPIO配置
Input       : 无
Return      : 无
Description : 按键P44上拉输入，LED P25推挽输出
*****************************************************************************/
void GPIO_Config(void)
{
    SYS_DisableIOCFGProtect();  // 关闭IOCONFIG写保护
    SYS_DisableGPIO0Protect();  // 关闭GPIO0的相关寄存器写保护
    SYS_DisableGPIO1Protect();  // 关闭GPIO1的相关寄存器写保护
    SYS_DisableGPIO2Protect();  // 关闭GPIO2的相关寄存器写保护
    SYS_DisableGPIO3Protect();  // 关闭GPIO3的相关寄存器写保护
    SYS_DisableGPIO4Protect();  // 关闭GPIO4的相关寄存器写保护

    // 按键：上拉输入
    SYS_SET_IOCFG(IOP44CFG, SYS_IOCFG_P44_GPIO);
    GPIO_CONFIG_IO_MODE(GPIO4, GPIO_PIN_4, GPIO_MODE_INPUT_WITH_PULL_UP);

    // LED：推挽输出，
    //GPIO2->GPIO0DO &= ~GPIO_PIN_5_MSK;	//先关
    GPIO2->GPIO0DO |= GPIO_PIN_5_MSK;		//先开
    SYS_SET_IOCFG(IOP25CFG, SYS_IOCFG_P25_GPIO);
    GPIO_CONFIG_IO_MODE(GPIO2, GPIO_PIN_5, GPIO_MODE_OUTPUT);
}



/*****************************************************************************
Name        : ADC0初始化
Input       : 无
Return      : 无
Description : 单次转换模式，开CH19通道（电位器），软件启动轮询读取
*****************************************************************************/
void ADC0_Init(void)
{
    SYS_EnablePeripheralClk(SYS_CLK_ADC0_MSK);
    ADC0_ConfigRunMode(ADC0_CONVERT_SINGLE, ADC0_CLK_DIV_16);

    ADC0_EnableChannel(POT_ADC_CH_MSK);
    SYS_SET_IOCFG(IOP31CFG, SYS_IOCFG_P30_AN19);

    ADC0_Start();
}



/*****************************************************************************
Name        : 硬件除法器初始化
Input       : 无
Return      : 无
Description : 使能硬件除法器时钟，调用HWDIV_Div()前必须先调用
*****************************************************************************/
void HWDIV_Init(void)
{
    SYS_EnablePeripheralClk(SYS_CLK_HWDIVCE_MSK);
}



/*****************************************************************************
Name        : EPWM配置
Input       : 无
Return      : 无
Description : 配置EPWM为上下计数互补模式，16kHz（EPWM_FREQ），
              死区64计数 = 64/64MHz = 1.0us（N-MOS桥要求 >= 1us）。
              注意：需12V供电，仅在确认电路安全后调用。
*****************************************************************************/
void EPWM_Config(void)
{
    // 模式：上下计数 + 非对称 + 互补 + 独立输出
    EPWM_ConfigRunMode(EPWM_COUNT_UP_DOWN |
                       EPWM_OCU_ASYMMETRIC |
                       EPWM_WFG_COMPLEMENTARYK |
                       EPWM_OC_INDEPENDENT);

    // 时钟
    SYS_EnablePeripheralClk(SYS_CLK_EPWM_MSK);
    EPWM_ConfigChannelClk(EPWM0, EPWM_CLK_DIV_1);
    EPWM_ConfigChannelClk(EPWM2, EPWM_CLK_DIV_1);
    EPWM_ConfigChannelClk(EPWM4, EPWM_CLK_DIV_1);

    // 周期（上下计数装半周期2000）
    EPWM_ConfigChannelPeriod(EPWM0, (uint16_t)EPWM_PERIOD / 2);
    EPWM_ConfigChannelPeriod(EPWM2, (uint16_t)EPWM_PERIOD / 2);
    EPWM_ConfigChannelPeriod(EPWM4, (uint16_t)EPWM_PERIOD / 2);

    // 占空比先给50%（对管均分，无线电压差，电机无电流）
    EPWM_ConfigChannelAsymDuty(EPWM0, EPWM_PERIOD/4, EPWM_PERIOD/4);
    EPWM_ConfigChannelAsymDuty(EPWM2, EPWM_PERIOD/4, EPWM_PERIOD/4);
    EPWM_ConfigChannelAsymDuty(EPWM4, EPWM_PERIOD/4, EPWM_PERIOD/4);

    // 极性
    EPWM_DisableReverseOutput(EPWM_CH_0_MSK | EPWM_CH_1_MSK | EPWM_CH_2_MSK |
                              EPWM_CH_3_MSK | EPWM_CH_4_MSK | EPWM_CH_5_MSK);

    // 死区64计数 = 1.0us
    EPWM_EnableDeadZone(0x3F, (uint16_t)64);

    // 占空比自动加载，加载点=零点
    EPWM_EnableAutoLoadMode(EPWM_CH_0_MSK | EPWM_CH_2_MSK | EPWM_CH_4_MSK);
    EPWM_ConfigLoadAndIntMode(EPWM0, EPWM_EACH_PERIOD_ZERO);
    EPWM_ConfigLoadAndIntMode(EPWM1, EPWM_EACH_PERIOD_ZERO);
    EPWM_ConfigLoadAndIntMode(EPWM2, EPWM_EACH_PERIOD_ZERO);
    EPWM_ConfigLoadAndIntMode(EPWM3, EPWM_EACH_PERIOD_ZERO);
    EPWM_ConfigLoadAndIntMode(EPWM4, EPWM_EACH_PERIOD_ZERO);
    EPWM_ConfigLoadAndIntMode(EPWM5, EPWM_EACH_PERIOD_ZERO);

    // 在zero点加载占空比
    EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
    EPWM->CON3 |= 0x05550000;
    EPWM->LOCK = 0x0;

    // 计数比较器触发ADC1采样（触发点由SVPWM_Calc每周期更新，
    // 接收端配置在CurSample_Config：ADCCHPTG0=AN23，ADCCHPTG1=AN24）
    EPWM_ConfigCompareTriger(EPWM_CMPTG_0, EPWM_CMPTG_FALLING, EPWM_CMPTG_EPWM0,
                             (uint16_t)((EPWM_PERIOD/2) >> 2));
    EPWM_ConfigCompareTriger(EPWM_CMPTG_1, EPWM_CMPTG_FALLING, EPWM_CMPTG_EPWM0,
                             (uint16_t)((EPWM_PERIOD/2) >> 1));

    // 刹车暂不使用
    EPWM_AllBrakeDisable();

    // 输出引脚复用
    SYS_SET_IOCFG(IOP01CFG, SYS_IOCFG_P01_EPWM0);
    SYS_SET_IOCFG(IOP04CFG, SYS_IOCFG_P04_EPWM1);
    SYS_SET_IOCFG(IOP05CFG, SYS_IOCFG_P05_EPWM2);
    SYS_SET_IOCFG(IOP06CFG, SYS_IOCFG_P06_EPWM3);
    SYS_SET_IOCFG(IOP07CFG, SYS_IOCFG_P07_EPWM4);
    SYS_SET_IOCFG(IOP47CFG, SYS_IOCFG_P47_EPWM5);
    EPWM_EnableOutput(EPWM_CH_0_MSK | EPWM_CH_1_MSK | EPWM_CH_2_MSK |
                      EPWM_CH_3_MSK | EPWM_CH_4_MSK | EPWM_CH_5_MSK);

    // 重映射：双N驱动
    EPWM->LOCK = EPWM_LOCK_P1B_WRITE_KEY;
    EPWM->POREMAP = 0xAA531420;
    EPWM->LOCK = 0;

    // 启动EPWM（50%占空比空转，等校准和按键）
    EPWM_Start(EPWM_CH_0_MSK | EPWM_CH_1_MSK | EPWM_CH_2_MSK |
               EPWM_CH_3_MSK | EPWM_CH_4_MSK | EPWM_CH_5_MSK);
    PWM_Out(ENABLE);
}



/*****************************************************************************
Name        : 中断配置
Input       : 无
Return      : 无
Description : NVIC总放闸，初始化序列最后一步调用（校准完成之后）。
              EPWM过零中断优先级1（16kHz快环），SysTick优先级3（1ms节拍）。
*****************************************************************************/
void Interrupt_Config(void)
{
    // EPWM过零中断（快环入口EPWM_IRQHandler在CurSample.c）
    EPWM->ICLR |= 0xFFFFFFFF;
    EPWM_EnableZeroInt(EPWM_CH_0_MSK);
    NVIC_SetPriority(EPWM_IRQn, 1);
    NVIC_EnableIRQ(EPWM_IRQn);

    // SysTick中断（SysTick_Handler在main.c）
    NVIC_SetPriority(SysTick_IRQn, 3);
    NVIC_EnableIRQ(SysTick_IRQn);
}




/*****************************************************************************
Name        : 运放1配置
Input       : 无
Return      : 无
Description : 内部运放OP1配置。
              放大电路在板上（R27/R26定了10倍增益，R15/R17定了1V偏置），
              芯片内部只当"裸运放"用，配成传统运放模式。
*****************************************************************************/
void OPA1_Config(void)
{
    uint32_t adj;

    SYS_EnablePeripheralClk(SYS_CLK_OPA_PGA_MSK);       /* 开运放模块时钟 */

    adj = OPA_GetAutoAdjustResult(OPA1);                /* 出厂的失调校正值 */

    OPA_ConfigRunMode(OPA1, OPA_FIL_OPA);               /* 裸运放模式（不接内部电阻链） */
    OPA_ConfigPositive(OPA1, OPA_POSSEL_P);             /* 同相端接OP1P引脚 */
    OPA_ConfigNegative(OPA1, OPA_NEGSEL_N);             /* 反相端接OP1N引脚 */
    OPA_ConfigOutput(OPA1, OPA_OUTSEL_O);               /* 输出接OP1O引脚 */
    OPA_EnableOPADJAdjust(OPA1, adj);                   /* 施加失调校正 */

    SYS_SET_IOCFG(IOP21CFG, SYS_IOCFG_P21_OP1P);        /* P21复用为运放同相端 */
    SYS_SET_IOCFG(IOP17CFG, SYS_IOCFG_P17_OP1N);        /* P17复用为运放反相端 */
    SYS_SET_IOCFG(IOP16CFG, SYS_IOCFG_P16_OP1O);        /* P16复用为运放输出 */

    OPA_Start(OPA1);                                    /* 启动运放 */
}



/*****************************************************************************
Name        : 电流采样配置
Input       : 无
Return      : 无
Description : ADC1硬件触发采样配置。

              触发链路（"谁触发谁"）：
              EPWM比较触发器0/1发脉冲（触发点数值由SVPWM_Calc每周期更新）
                  |
                  v
              ADC1的ADCHWTG寄存器（PTG0EN/PTG1EN = 两条触发线路开关）
                  |
                  v
              ADCCHPTG0寄存器（选AN23 -> 触发0来时转换AN23）
              ADCCHPTG1寄存器（选AN24 -> 触发1来时转换AN24）

              注意：用户工程的adc1.c驱动是旧版，没有类触发API，
              这里两处直接写寄存器（寄存器名见CMS32M55xx.h的ADC1_Type）。
*****************************************************************************/
void CurSample_Config(void)
{
    SYS_EnablePeripheralClk(SYS_CLK_ADC1_MSK);          /* 开ADC1时钟 */

    /* 连续转换模式 + ADC时钟16MHz + 采样保持10.5个ADC时钟(0.66us)
       采样保持时间要小于触发提前量TGBFR(0.75us)：
       保证窗口一（下桥导通段）前完成对模拟量的锁存 */
    ADC1_ConfigRunMode(ADC1_CONVERT_CONTINUOUS, ADC1_CLK_DIV_4, ADC1_HOLD_10P5_CLK);

    SYS_SET_IOCFG(IOP35CFG, SYS_IOCFG_P35_AN23);        /* P35复用为模拟输入AN23 */
    SYS_SET_IOCFG(IOP36CFG, SYS_IOCFG_P36_AN24);        /* P36复用为模拟输入AN24 */

    /* EPWM触发到ADC启动之间的延时 = 0（触发点已含提前量，无需二次延时） */
    ADC1->ADCLOCK = ADC1_LOCK_WRITE_KEY;                /* 解锁ADC1写保护 */
    ADC1->ADCPWMTGDLY = 0u;
    ADC1->ADCLOCK = 0u;                                 /* 重新上锁 */

    ADC1_Start();                                       /* 使能ADC1 */
    ADC1_StartAdjust();                                 /* 启动一次自校准转换 */
    ADC1_EnableAdjust();                                /* 转换结果应用校准值 */

    /* 触发组到通道的映射 + 使能两路EPWM比较触发 */
    ADC1->ADCLOCK = ADC1_LOCK_WRITE_KEY;
    ADC1->ADCCHPTG0 |= ADC1_CH_23_MSK;                  /* 触发0 -> AN23 */
    ADC1->ADCCHPTG1 |= ADC1_CH_24_MSK;                  /* 触发1 -> AN24 */
    ADC1->ADCHWTG   |= (ADC1_HWTG_ADCPTG0EN_Msk | ADC1_HWTG_ADCPTG1EN_Msk);
    ADC1->ADCLOCK = 0u;
}



/*****************************************************************************
Name        : 电流零偏校准（阻塞约16ms）
Input       : 无
Return      : 无
Description : 见CurSample.h。轮询EPWM过零标志（RIS原始状态位，
              不依赖NVIC），每个PWM周期取一次两路ADC结果累加，
              256个周期后取平均，覆盖g_CurOffset1/2。
              前提：EPWM已启动、占空比50%、电机无电流、NVIC还没放闸。
*****************************************************************************/
void CurSample_Calib(void)
{
    uint32_t sum1 = 0u;
    uint32_t sum2 = 0u;
    uint16_t i;

    for (i = 0u; i < (uint16_t)CS_CALIB_NUM; i++)
    {
        EPWM->ICLR = (0x1UL << EPWM_ICLR_ZIFn_Pos);     /* 清EPWM0过零标志 */
        while ((EPWM->RIS & (0x1UL << EPWM_RIS_ZIFn_Pos)) == 0u)
        {
            ;                                           /* 等下一次过零 */
        }
        sum1 += (uint32_t)(ADC1->ADCDATA[23] & 0x0FFFu);
        sum2 += (uint32_t)(ADC1->ADCDATA[24] & 0x0FFFu);
    }

    g_CurOffset1 = (uint16_t)(sum1 / CS_CALIB_NUM);
    g_CurOffset2 = (uint16_t)(sum2 / CS_CALIB_NUM);
}



/*****************************************************************************
Name        : SysTick中断
Input       : 无
Return      : 无
Description : 1ms节拍源，只置标志，活都在主循环里干。
*****************************************************************************/
void SysTick_Handler(void)
{
    SysTick->CTRL |= SysTick_CTRL_COUNTFLAG_Msk;    // 读清COUNTFLAG
    s_Tick1msFlag = 1u;
}



/*****************************************************************************
Name        : 主函数
Input       : 无
Return      : 无
Description : 上电初始化 -> 阻塞校准 -> 开中断 -> 1ms主循环。
              CurSample_Calib阻塞约16ms（256个PWM周期取电流偏置），
              校准没完成前NVIC未使能、电机不会得电，天然替代上电延时。
              主循环只做三件事：扫按键、扫电位器、跑电机状态机。
*****************************************************************************/
int main(void)
{
    SysClock_Init();        // 时钟64MHz
    GPIO_Config();          // 按键/LED引脚
    SysTick_Init();         // 1ms节拍
    ADC0_Init();            // 电位器采样
    OPA1_Config();          // 电流运放OP1
    CurSample_Config();     // ADC1双触发采样
    HWDIV_Init();           // 硬件除法器
    EPWM_Config();          // 三相PWM（50%占空比起步，无电流）
    CurSample_Calib();      // 阻塞校准电流偏置（约16ms）
    Motor_Init();           // 电机状态机 + 观测器 + 三环PI
    Interrupt_Config();     // NVIC放闸，16kHz快环开跑

    while (1)
    {
        if (s_Tick1msFlag)
        {
            s_Tick1msFlag = 0u;
            KeyScan();
            Pot_Scan();
            Motor_StateHandle();
        }
    }
}

